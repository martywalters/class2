# -*- coding: utf-8 -*-
"""
Created on Sat Mar  2 12:04:57 2024

@author: walters
"""

def add(x, y):

    return x + y

def subtract(x, y):
    return x-y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y==0:
        raise ValueError('Cannot divide by zero!')
    return x / y;